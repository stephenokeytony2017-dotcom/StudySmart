# StudySmart Android App

This Android wrapper opens the live StudySmart website at:
https://stevelearningtool-mechatronics.netlify.app/

Features:
- Live Netlify Identity login/signup
- StudySmart app icon
- Android launch splash screen
- Friendly offline/retry screen
- WebView loading progress indicator
- Android back-button navigation
- JavaScript, DOM storage, cookies and Netlify Identity support

Build with GitHub Actions or Gradle using Java 17 and Android SDK 35.
