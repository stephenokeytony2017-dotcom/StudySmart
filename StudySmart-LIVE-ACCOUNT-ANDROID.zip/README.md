# StudySmart Android

Android wrapper for the StudySmart LIVE ACCOUNT web app.

Build: `gradle assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`
