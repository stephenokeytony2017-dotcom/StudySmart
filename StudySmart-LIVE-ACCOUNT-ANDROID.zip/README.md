# StudySmart Android App

StudySmart Android wrapper for the live StudySmart site.

Live site: https://stevelearningtool-mechatronics.netlify.app/

## Version 4.0
- Live Netlify site origin for Netlify Identity login/signup
- Branded splash/loading screen and StudySmart launcher icon
- WebView JavaScript, DOM storage, cookies and session persistence
- Back navigation with double-back exit protection
- Offline/retry screen
- Web file chooser/upload support
- Android Download Manager support
- External tel/mailto/WhatsApp/intent/market links
- State restoration after recreation
- Debug APK build
- Release APK and AAB build prepared for later signing/Play Store release

### Important
The release APK/AAB produced by GitHub Actions is unsigned until a release keystore is configured. The debug APK is the normal installable test build.


## Version 6.0

This release keeps StudySmart connected to the live Netlify site and strengthens the Android shell: Safe Browsing where supported, multi-file chooser handling, web-renderer recovery, release APK/AAB builds, and SHA-256 checksums.

The release AAB/APK produced by GitHub Actions is unsigned and is intended to be signed with the final developer keystore before Play Store publication.
