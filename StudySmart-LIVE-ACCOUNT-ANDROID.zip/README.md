# StudySmart Android App

This Android WebView app opens the live StudySmart Netlify site so Netlify Identity account login/signup uses the live site origin.

Live site: https://stevelearningtool-mechatronics.netlify.app/

Build with Gradle 8.7 and Java 17.
