package com.studysmart.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://stevelearningtool-mechatronics.netlify.app/";
    private static final int FILE_CHOOSER_REQUEST = 1001;

    private WebView webView;
    private ProgressBar progressBar;
    private View splashView;
    private TextView offlineView;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean backPressedOnce = false;
    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            configureSystemBars();
            buildInterface();
            if (savedInstanceState != null) {
                webView.restoreState(savedInstanceState);
                hideSplashSoon();
            } else {
                loadStudySmart();
            }
        } catch (Throwable t) {
            showStartupError(t);
        }
    }

    private void showStartupError(Throwable error) {
        try {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setPadding(48, 48, 48, 48);
            box.setBackgroundColor(0xFFFFFFFF);

            TextView title = new TextView(this);
            title.setText("StudySmart");
            title.setTextSize(28);
            title.setTextColor(0xFF2563EB);
            title.setTypeface(null, android.graphics.Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            box.addView(title, new LinearLayout.LayoutParams(-1, -2));

            TextView message = new TextView(this);
            message.setText("The app could not start the learning page.\n\nPlease check your internet connection and try again.\n\nError: " + error.getClass().getSimpleName());
            message.setTextSize(16);
            message.setTextColor(0xFF334155);
            message.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
            mp.topMargin = 20;
            box.addView(message, mp);

            TextView retry = new TextView(this);
            retry.setText("Tap here to retry");
            retry.setTextSize(17);
            retry.setTextColor(0xFF2563EB);
            retry.setGravity(Gravity.CENTER);
            retry.setPadding(20, 28, 20, 28);
            retry.setOnClickListener(v -> recreate());
            box.addView(retry, new LinearLayout.LayoutParams(-1, -2));
            setContentView(box);
        } catch (Throwable ignored) {
            finish();
        }
    }

    private void configureSystemBars() {
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    private void buildInterface() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFFFFFFFF);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setLoadsImagesAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " StudySmartAndroid/8.0");

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setBackgroundColor(0xFFFFFFFF);
        webView.setWebViewClient(new StudySmartWebViewClient());
        webView.setWebChromeClient(new StudySmartChromeClient());
        webView.setDownloadListener(new StudySmartDownloadListener());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);

        offlineView = new TextView(this);
        offlineView.setText("StudySmart\n\nNo internet connection or the page could not be loaded.\n\nTap here to try again");
        offlineView.setTextSize(17);
        offlineView.setGravity(Gravity.CENTER);
        offlineView.setPadding(48, 48, 48, 48);
        offlineView.setVisibility(View.GONE);
        offlineView.setOnClickListener(v -> loadStudySmart());
        offlineView.setBackgroundColor(0xFFFFFFFF);
        offlineView.setTextColor(0xFF1F2937);

        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(-1, 7);
        root.addView(progressBar, barParams);
        root.addView(offlineView, new FrameLayout.LayoutParams(-1, -1));

        splashView = createSplashView();
        root.addView(splashView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private View createSplashView() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(0xFFFFFFFF);
        splash.setPadding(40, 40, 40, 40);

        ImageView icon = new ImageView(this);
        icon.setImageResource(com.studysmart.app.R.drawable.ic_studysmart_foreground);
        int size = (int) (96 * getResources().getDisplayMetrics().density);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(size, size);
        iconParams.bottomMargin = 18;
        splash.addView(icon, iconParams);

        TextView title = new TextView(this);
        title.setText("StudySmart");
        title.setTextSize(28);
        title.setTextColor(0xFF2563EB);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        splash.addView(title, new LinearLayout.LayoutParams(-2, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Learn smarter. Practice better.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFF64748B);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-2, -2);
        subParams.topMargin = 6;
        splash.addView(subtitle, subParams);

        ProgressBar loading = new ProgressBar(this);
        LinearLayout.LayoutParams loadParams = new LinearLayout.LayoutParams(-2, -2);
        loadParams.topMargin = 26;
        splash.addView(loading, loadParams);
        return splash;
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void loadStudySmart() {
        if (webView == null) return;
        offlineView.setVisibility(View.GONE);
        splashView.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);
        webView.loadUrl(HOME_URL);
    }

    private void showOffline() {
        progressBar.setVisibility(View.GONE);
        offlineView.setVisibility(View.VISIBLE);
    }

    private void hideSplashSoon() {
        handler.postDelayed(() -> {
            if (splashView != null) splashView.setVisibility(View.GONE);
        }, 450);
    }

    private class StudySmartWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUrl(request.getUrl().toString());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUrl(url);
        }

        private boolean handleUrl(String url) {
            if (url == null) return false;
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            if (scheme == null) return false;

            if ("tel".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)
                    || "whatsapp".equalsIgnoreCase(scheme) || "intent".equalsIgnoreCase(scheme)
                    || "market".equalsIgnoreCase(scheme)) {
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "No app is available to open this link.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            offlineView.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            progressBar.setVisibility(View.GONE);
            hideSplashSoon();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            if (request.isForMainFrame()) {
                splashView.setVisibility(View.GONE);
                showOffline();
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
            splashView.setVisibility(View.GONE);
            showOffline();
            Toast.makeText(MainActivity.this, "StudySmart restarted the web page after an unexpected error.", Toast.LENGTH_LONG).show();
            return true;
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                splashView.setVisibility(View.GONE);
                showOffline();
            }
        }
    }

    private class StudySmartChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setProgress(newProgress);
            if (newProgress >= 100) progressBar.setVisibility(View.GONE);
            else if (offlineView.getVisibility() != View.VISIBLE) progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            result.cancel();
            return true;
        }

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                         FileChooserParams fileChooserParams) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            try {
                Intent intent = fileChooserParams.createIntent();
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            } catch (Exception e) {
                filePathCallback = null;
                Toast.makeText(MainActivity.this, "Unable to open file picker.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
    }

    private class StudySmartDownloadListener implements DownloadListener {
        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                    String mimetype, long contentLength) {
            try {
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimetype);
                request.addRequestHeader("User-Agent", userAgent);
                request.setTitle("StudySmart download");
                request.setDescription("Downloading from StudySmart");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        "StudySmart-" + System.currentTimeMillis());
                dm.enqueue(request);
                Toast.makeText(MainActivity.this, "Download started.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "Unable to download this file.", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else {
                    Uri uri = data.getData();
                    if (uri != null) results = new Uri[]{uri};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            backPressedOnce = false;
            return;
        }
        if (backPressedOnce) {
            super.onBackPressed();
            return;
        }
        backPressedOnce = true;
        Toast.makeText(this, "Press back again to exit StudySmart", Toast.LENGTH_SHORT).show();
        handler.postDelayed(() -> backPressedOnce = false, 1800);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }
}
